﻿using System;

namespace oef1ExceptionHandeling
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            int[] myNum = { 10, 20, 30};
            bool herhaal = true;
            while (herhaal)
            {


                try
                {
                    Console.WriteLine("geef een index op");
                    int index = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine(myNum[index]);
                    herhaal = false;
                }

                catch (IndexOutOfRangeException ie)
                {
                    Console.WriteLine("de opgegeven index is te hoog");
                    herhaal = true;
                }

                catch (FormatException fe)
                {
                    Console.WriteLine("geef een getal op");
                    herhaal = true;
                }
                finally
                {
                    if (herhaal == false)
                    {
                      Console.WriteLine("succesfull");
                    }
                    
                }
            }
           
        }
    }
}
