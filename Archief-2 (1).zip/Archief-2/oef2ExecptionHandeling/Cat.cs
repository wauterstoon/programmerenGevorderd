﻿using System;
using System.Collections.Generic;
namespace oef2ExecptionHandeling
{
    public class EmployeeListNotFoundException : Exception
    {
        public EmployeeListNotFoundException()
        {

        }

        public EmployeeListNotFoundException(string message)
            : base(message)
        {

        }

        public EmployeeListNotFoundException(string message, Exception inner)
            : base(message, inner)
        {

        }

        public class Cat
        {
            public Cat(int age)
            {
                this.age = age;
            }

            public int age { get; set; }
           

            public static int ControleerLeeftijd(int leeftijd)
            {
                return leeftijd;
            }
        }
    }
}