﻿using System;
using System.Collections.Generic;
namespace oef2ExecptionHandeling
{
    public class CatAgeException : Exception
    {
        public CatAgeException()
        {
        }

        public CatAgeException(string message)
            : base(message)
        {
        }

        public CatAgeException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }
    public class Cat
    {
        public Cat(int age)
        {
            Age = age;
        }

        public int Age { get; set; }
       public  int ControleerLeeftijd(int age)
        {
            try
            {
                if (age == 0 || age < 0)
                {
                    throw new CatAgeException();
                }
            }
            catch (CatAgeException cx)
            {
                Console.WriteLine("De leeftijd kan niet kleiner of gelijk zijn aan nul!");
            }
            return age;
        }
    }
    class MainClass
    {
        public static void Main(string[] args)
        {
            List<Cat> cats = new List<Cat>();
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("geef een leeftijd op");
                int leeftijd = Convert.ToInt32(Console.ReadLine());
                Cat c = new Cat(leeftijd);
                c.ControleerLeeftijd(leeftijd);
                cats.Add(c);
            }

        }
    }
}
