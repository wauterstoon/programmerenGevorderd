﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace OpdrachtFilesIO
{
    class CodeFileInfo
    {
        public string NameSpace { get; set; }
        public string Name { get; set; }
        public int LinesOfCode { get; set; }
        public bool IsClass { get; set; }
        public bool IsInterface { get; set; }
        public FileInfo FileInfo { get; set; }

        

        public override string ToString()
        {
            string s = "";
            if (IsClass) s += "(class)";
            if (IsInterface) s += "(Interface)";
            s += NameSpace + "," + Name + "," + LinesOfCode.ToString();
            return s;
        }
    }
}
