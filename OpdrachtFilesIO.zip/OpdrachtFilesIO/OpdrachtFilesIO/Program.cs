﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;


namespace OpdrachtFilesIO
{
    class Program
    {
        static void Main(string[] args)
        {
        ClassInfo CI = new ClassInfo();
        //inlezen van data 
        var reader = new StreamReader(File.OpenRead(@"C:\Users\waute\Desktop\boten\boten\Rederij.cs"));
            string code = "";
            List<string> woorden = new List<string>();
            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                code += line;
            }
            Console.WriteLine("--BEGIN CODE--");
            Console.WriteLine(code);// Code staat nu op 1 lijn
            Console.WriteLine("--EINDE CODE--");
            code = CI.GetUsings(code);
            code = CI.GetNameSpace(code);
            code = CI.GetClassName(code);
            code = CI.AnaliseerCode(code);
            CI.Show();
            Console.WriteLine(code);

        }
    }
}


