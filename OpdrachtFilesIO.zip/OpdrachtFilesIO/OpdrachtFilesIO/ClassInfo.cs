﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OpdrachtFilesIO
{
    class ClassInfo
    {
        public string Name { get; set; }
        public string NameSpace { get; set; }
        public List<string> constructors { get; set; }
        public List<string> methods { get; set; }
        public List<string> inherits { get; set; }
        public List<string> usings { get; set; }
        public List<string> properties { get; set; }
        public List<string> parameters { get; set; }


        List<string> Usings = new List<string>();
        List<string> Properties = new List<string>();


        public string GetNameSpace(string code)
        {
            while (code.StartsWith("namespace"))
            {
                int indexOpenAcolade = code.IndexOf("{");
                string resulstaat = code.Substring(0, indexOpenAcolade);
                var split = resulstaat.Split(" ");
                string naamNameSpace = split[1];
                NameSpace = naamNameSpace;
                //namespaces die ingelezen is verwijderen uit de code
                string nieuweCode = code.Replace(code.Substring(0, indexOpenAcolade + 1), "");
                code = nieuweCode;
            }
            return code;
        }
        public string GetUsings(string code)
        {        
            while (code.StartsWith("using"))
            {
                int indexPuntKomma = code.IndexOf(";");
                string resulstaat = code.Substring(0, indexPuntKomma);
                var split = resulstaat.Split(" ");
                string naamUsing = split[1];
                Usings.Add(naamUsing);
                string nieuweCode = code.Replace(code.Substring(0, indexPuntKomma + 1), "");
                code = nieuweCode;
            }
            return code;
        }

        public string GetClassName(string code)
        {
            int indexEnum = code.IndexOf("Enum");
            int indexInterFace = code.IndexOf("interface");
            int indexClass = code.IndexOf("class");
            string overerving = "";
            if (indexEnum == -1 && indexInterFace == -1)
            {
                int indexOpenAcolade = code.IndexOf("{");
                string resulstaat = code.Substring(indexClass, indexOpenAcolade);
                var split = resulstaat.Split(" ");
                string naamclass = split[1];
                Name = naamclass;
                string nieuweCode = code.Replace(code.Substring(0, indexOpenAcolade + 1), "");
                code = nieuweCode;
            }
            else if (indexClass == -1 && indexEnum == -1)
            {
                int indexOpenAcolade = code.IndexOf("{");
                string resulstaat = code.Substring(indexInterFace, indexOpenAcolade);
                var split = resulstaat.Split(" ");
                string naamInterface = split[1];
                Name = naamInterface;
                string nieuweCode = code.Replace(code.Substring(0, indexOpenAcolade + 1), "");
                code = nieuweCode;
            }
            else if (indexClass == -1&& indexInterFace==-1)
            {
                int indexOpenAcolade = code.IndexOf("{");
                string resulstaat = code.Substring(indexEnum, indexOpenAcolade);
                var split = resulstaat.Split(" ");
                string naamEnum = split[1];
                Name = naamEnum;
                string nieuweCode = code.Replace(code.Substring(0, indexOpenAcolade + 1), "");
                code = nieuweCode;
            }
            return code;
        }

        public string AnaliseerCode(string code)
        {
            int indexPuntKomma = code.IndexOf(";"); //parameter
            int indexOpenHaakjes = code.IndexOf("("); //methode 
            int indexOpenAcolade = code.IndexOf("{"); //property

            if (indexOpenAcolade < indexOpenHaakjes && indexOpenAcolade < indexPuntKomma)
            {
                // property
                int indexSluitenAcolade = code.IndexOf("}");
                string volledigeProperty = code.Substring(0, indexSluitenAcolade+1);
                string spatiesVooraanWeg = volledigeProperty.TrimStart();
                var split = spatiesVooraanWeg.Split(" ");
                string naamProperty = split[2];
                Properties.Add(naamProperty);
                string nieuweCode = code.Replace(code.Substring(0, indexSluitenAcolade + 1),"");
                code = nieuweCode;
            }
            else if (indexOpenHaakjes < indexPuntKomma && indexOpenHaakjes < indexOpenAcolade)
            {
                //methode
            }
            else if (indexPuntKomma < indexOpenHaakjes && indexPuntKomma < indexOpenAcolade)
            {
                //parameter
            }
            return code;
        }


        public void Show()
        {
            Console.WriteLine($"{NameSpace},{Name}");
            //foreach (string s in constructors) Console.WriteLine($"Constructor : {s}");
            //foreach (string s in methods) Console.WriteLine($"method : {s}");
            //foreach (string s in inherits) Console.WriteLine($"inherit : {s}");
            foreach (string s in Usings) Console.WriteLine($"usings : {s}");
            foreach (string s in Properties) Console.WriteLine($"property : {s}");
            //foreach (string s in parameters) Console.WriteLine($"paramter : {s}");
            Console.WriteLine("_________________________");
        }
    }
}
