﻿using boten.Boten;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace boten
{
    class Vloot
    {
        public string NaamVloot { get; set; }
        Dictionary<string, List<Ships>> VlotenDict = new Dictionary<string, List<Ships>>();


        public void VoegBootBijVloot(string vlootNaam, List<Ships> Boten)
        {
            if (VlotenDict.ContainsKey(vlootNaam))
            {
                VlotenDict.Add(vlootNaam, Boten);
            }
            else
            {
                VlotenDict.Add(vlootNaam, Boten);
            }
        }
        public void VerwijderBootVanVloot(string vlootNaam, string bootNaam)
        {
            if (VlotenDict.ContainsKey(vlootNaam))
            {
                VlotenDict.Remove(bootNaam);
            }
        }
    }
}
