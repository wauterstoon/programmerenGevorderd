﻿using System;
using System.Collections.Generic;
using System.Text;

namespace boten
{
    class Rederij
    {
        public string RederijNaam { get; set; }
        List<string> Havens = new List<string>();
        Dictionary<string, List<Vloot>> VlotenDict = new Dictionary<string, List<Vloot>>();
        Dictionary<String, List<string>> HavensAanRederijDict = new Dictionary<string, List<string>>();
        public void VoegVlootBijRederij(string vlootNaam, List<Vloot> Vloten)
        {
            if (VlotenDict.ContainsKey(RederijNaam))
            {
                VlotenDict.Add(RederijNaam, Vloten);
            }
            else
            {
                VlotenDict.Add(RederijNaam, Vloten);
            }
        }
        public void VerwijderBootVanVloot(string RederijNaam, string VlootNaam)
        {
            if (VlotenDict.ContainsKey(RederijNaam))
            {
                VlotenDict.Remove(VlootNaam);
            }
        }
        public void voegHavensToe(string rederijNaam, List<string>Havens)
        {
            if (HavensAanRederijDict.ContainsKey(RederijNaam))
            {
                HavensAanRederijDict.Add(RederijNaam, Havens);
            }
            else
            {
                HavensAanRederijDict.Add(RederijNaam, Havens);
            }
        }
        public string PrintHavens(List<string> Havens)
        {
            Havens.Sort();
            string haven = "";
            foreach (string h in Havens)
            {
                 haven = h;
            }
            return haven;
        }
    }
}
