﻿using boten.Boten;
using System;
using System.Collections.Generic;
using System.Text;

namespace boten
{
    class GasTanker : Ships
    {
        public GasTanker(string naam, double lengte, double breedte, double tonnage, double cargoWaarde, double liters, LadingGasTanker lading) : base(naam, lengte, breedte, tonnage)
        {
            Naam = naam;
            Lengte = lengte;
            Breedte = breedte;
            Tonnage = tonnage;
            CargoWaarde = cargoWaarde;
            Liters = liters;
            Lading = lading;
        }

     
        public double CargoWaarde { get; set; }
        public double Liters { get; set; }
        public LadingGasTanker Lading { get; set; }
    }
}
