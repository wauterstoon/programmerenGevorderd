﻿using boten.Boten;
using System;
using System.Collections.Generic;
namespace boten
{
    class Program
    {
        static void Main(string[] args)
        {
            //per vloot moet dus een nieuwe list gemaakt worden en daar in moeten de boten gestoken worden
            //er moet ook van elke boot een nieuwe instantie gemaakt worden...
            
            List<Ships> schepen = new List<Ships>();
            Sleepboot slb = new Sleepboot("sleeper", 18, 8, 12);
            OlieTanker OT = new OlieTanker("OlieVat", 100, 32, 280, 2000000, 127868, LadingOlieTanker.diesel);
            schepen.Add(slb);
            schepen.Add(OT);

            Dictionary<string, List<Ships>> Vloten = new Dictionary<string, List<Ships>>();
            Vloten.Add("NoordZeeVloot", schepen);
           
            
        }
    }
}
