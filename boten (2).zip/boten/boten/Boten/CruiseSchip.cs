﻿using boten.Boten;
using System;
using System.Collections.Generic;
using System.Text;

namespace boten
{
    class CruiseSchip : Ships
    {
        public CruiseSchip(string naam, double lengte, double breedte, double tonnage, int aantalPassagiers, List<string> traject) : base(naam, lengte, breedte, tonnage)
        {
            Naam = naam;
            Lengte = lengte;
            Breedte = breedte;
            Tonnage = tonnage;
            AantalPassagiers = aantalPassagiers;
            Traject = traject;
        }

        public int AantalPassagiers { get; set; }
        public List<String>Traject { get; set; }

    }
}
