﻿using boten.Boten;
using System;
using System.Collections.Generic;
using System.Text;

namespace boten
{
    class ContainerSchip :Ships
    {
        public ContainerSchip(string naam, double lengte, double breedte, double tonnage, int aantalContainers, double cargoWaarde) : base(naam, lengte, breedte, tonnage)
        {
            Naam = naam;
            Lengte = lengte;
            Breedte = breedte;
            Tonnage = tonnage;
            AantalContainers = aantalContainers;
            CargoWaarde = cargoWaarde;
        }

   
        public int AantalContainers { get; set; }
        public double CargoWaarde { get; set; }

    }
}
