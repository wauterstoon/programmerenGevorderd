﻿using boten.Boten;
using System;
using System.Collections.Generic;
using System.Text;

namespace boten
{
    class Sleepboot : Ships
    {
        public Sleepboot(string naam, double lengte, double breedte, double tonnage) : base(naam, lengte, breedte, tonnage)
        {
            Naam = naam;
            Lengte = lengte;
            Breedte = breedte;
            Tonnage = tonnage;
            
            
        }

       
    }
}
