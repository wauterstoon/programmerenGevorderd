﻿using System;
using System.Collections.Generic;
using System.Text;

namespace boten
{
    enum LadingGasTanker
    {
        LPG,LNG,amoniak

    }
}
