﻿using System;
using System.Collections.Generic;
using System.Text;

namespace boten
{
    enum LadingOlieTanker
    {olie,benzeen,diesel,nafta
    }
}
