﻿using boten.Boten;
using System;
using System.Collections.Generic;
using System.Text;

namespace boten
{
    class Veerboot : Ships
    {
        public Veerboot(string naam, double lengte, double breedte ,double tonnage,int aantalPassagiers, List<string> traject):base(naam,lengte,breedte,tonnage)
        {
            
            AantalPassagiers = aantalPassagiers;
            Traject = traject;
            Naam = naam;
            Lengte = lengte;
            Breedte = breedte;
            Tonnage = tonnage;

        }

      
        public int AantalPassagiers { get; set; }
        public List<string> Traject { get; set; }

    }
}
