﻿using System.Windows;
using System.Windows.Controls;

namespace BegeleideOefWPF
{
    /// <summary>
    /// Interaction logic for DerdeVoorbeeld.xaml
    /// </summary>
    public partial class DerdeVoorbeeld : Window
    {
        public DerdeVoorbeeld()
        {
            InitializeComponent();
        }
        private bool _inhoudeTextboxChanged;
        private void InhoudTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            _inhoudeTextboxChanged = true;
        }
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (_inhoudeTextboxChanged)
            {
                MessageBoxResult antwoord = MessageBox.Show("er zijn wijzigingen aangebracht, wilt u deze bewaren?", Title, MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
                if (antwoord == MessageBoxResult.Yes)
                {
                    Opslaan();
                }
                else if (antwoord == MessageBoxResult.No)
                {
                    //niks
                }
                else
                {
                    e.Cancel = true;
                }
            }
        }
        private void OpslaanMenuItem_Click(object sender, RoutedEventArgs e)
        {
            Opslaan();
        }
        private void Opslaan() {
            _inhoudeTextboxChanged = false;
            MessageBox.Show("De wijzigingen zijn bewaard.", Title, MessageBoxButton.OK, MessageBoxImage.Information);
        }
        private void AfsluitenMenuItem_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }

}
