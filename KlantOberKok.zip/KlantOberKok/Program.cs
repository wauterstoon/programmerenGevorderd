﻿using System;
using BusinessLayer;

namespace KlantOberKok
{
    class Program
    {
        static void Main(string[] args)
        {
            Klant klant1 = new Klant("Piet");
            Klant klant2 = new Klant("Jef");
            Bel bel = new Bel();

            BestellingsSysteem bs = new BestellingsSysteem();
            Ober ober = new Ober("Jan")
            {
                bestellingsSysteem = bs,
                Bel =bel,
            };

            Kok k = new Kok("Marie")
            {
                BestellingsSysteem = bs,
                Bel = bel,
            };

            klant1.Bestel(ober, "Hoegaarden");
            klant2.Bestel(ober, "koffie");

            Console.ReadKey();
         }
    }
}
