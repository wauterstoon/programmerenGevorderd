﻿using System;
using System.Collections.Generic;
using System.Linq;
using BusinessLayer.Events;

namespace BusinessLayer
{
    public class Ober
    {
        //props
        private List<Klant> _klanten = new List<Klant>();
        public string Naam { get; set; }
        public BestellingsSysteem bestellingsSysteem { get; set; }


        private Bel _bel;

        public Bel Bel
        {
            get
            {
                return this._bel;
            }
            set
            {
                if (this._bel != null) this._bel.RingEvent -= this.BelGehoord;
                this._bel = value;
                this._bel.RingEvent += BelGehoord;
            }
        }


        //ctor
        public Ober(string naam)
        {
            this.Naam = naam;
        }

        //methods
        public void BrengBestelling(Klant k , string p)
        {
            if (k == null || string.IsNullOrEmpty(p)) return;

            if (!_klanten.Contains(k))
            {
                _klanten.Add(k);
                bestellingsSysteem.GeefBestellingIn(new BestelEventArgs { Klant = k.Naam, Product = p });
            }
           
        }

        private void BelGehoord(object sender , BestelEventArgs args)
        {
            var klant = this._klanten.Where(k => k.Naam == args.Klant).FirstOrDefault();
            if (klant == null) return;
            klant.Betaal(args.Product);
            klant.Consumeer(args.Product);
        }
    }
}
