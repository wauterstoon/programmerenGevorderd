﻿using System;
using BusinessLayer.Events;

namespace BusinessLayer
{
    public class BestellingsSysteem
    {
        //events
        public event EventHandler<BestelEventArgs> BestellingEvent;
       

            //methods
            public void GeefBestellingIn(BestelEventArgs args)
            {
            //vraagteken is als het niet null is , altijd eerste argument is This.
                BestellingEvent?.Invoke(this, args);

            }
        }
    }

