﻿using System;
using BusinessLayer.Events;

namespace BusinessLayer
{
    public class Bel
    {
        // events
        public event EventHandler<BestelEventArgs> RingEvent;
        //methods
        public void Ring(BestelEventArgs args)
        {
            RingEvent?.Invoke(this, args);
        }
    }
}
