﻿using System;
namespace BusinessLayer.Events
{
    public class BestelEventArgs : EventArgs
    {
       //alle events erven over bvan EventArgs
        public string Klant { get; set; }
        public string Product { get; set; }

    
    
    }
}
