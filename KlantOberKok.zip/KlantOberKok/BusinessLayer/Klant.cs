﻿using System;

namespace BusinessLayer
{
    public class Klant
    {
        //properties
        public string Naam { get; set; }

        //Ctor
        public Klant(string naam)
        {
            Naam = naam;
        }
        //methods
        public void Betaal(string product)
        {
            Console.WriteLine(Naam + " betaal " +product);
        }
        public void Consumeer(string product)
        {
            Console.WriteLine(Naam + " eet " + product);
        }
        public void Bestel(Ober ober,string product)
        {
            if (ober == null || string.IsNullOrEmpty(product)) return;
            ober.BrengBestelling(this, product);
        }
    }
}
