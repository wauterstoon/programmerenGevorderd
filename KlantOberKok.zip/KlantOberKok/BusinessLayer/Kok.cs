﻿using System;
using BusinessLayer.Events;

namespace BusinessLayer
{
    public class Kok
    {
        //props
        public string Naam { get; set; }
        private BestellingsSysteem _bestellingsSysteem;
        public BestellingsSysteem BestellingsSysteem
        {
            get { return _bestellingsSysteem; }
            set
            {
                if (_bestellingsSysteem != null) _bestellingsSysteem.BestellingEvent -= BestellingOntvangen;
                _bestellingsSysteem = value;
                _bestellingsSysteem.BestellingEvent += BestellingOntvangen;
             
            } }

        public Bel Bel { get; set; }
        //ctor
        public Kok(string naam)
        {
            naam = naam;
        }
     //methods

        public void BestellingOntvangen(object sender , BestelEventArgs args)
        {
            if (args == null || string.IsNullOrEmpty(args.Product)) return; //preconditie kijken of alles ingevult is

            System.Console.WriteLine(args.Product + " in voorbereiding");
            System.Threading.Thread.Sleep(5000); // 5sec
            Bel.Ring(args);
          
        }
    }
}
