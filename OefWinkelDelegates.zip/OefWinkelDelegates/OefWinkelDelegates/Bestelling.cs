﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OefWinkelDelegates
{
   public class Bestelling
    {
        public ProductType type { get; set; }
        public double  prijs { get; set; }
        public int aantal { get; set; }
        public string adres { get; set; }
    }
}
