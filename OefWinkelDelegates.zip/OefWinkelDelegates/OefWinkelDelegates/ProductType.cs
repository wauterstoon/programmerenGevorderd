﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OefWinkelDelegates
{
    public enum ProductType
    {
        Tripel,
        Dubbel,
        Kriek,
        Pils

    }
}
