﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OefWinkelDelegates
{
    class Sales
    {
        //adres,list bestellingen
        private Dictionary<string, List<Bestelling>> _rapport = new Dictionary<string, List<Bestelling>>();

        public void OnWinkelVerkoop(object obj, WinkelEventArgs args)
        {
            if (!_rapport.ContainsKey(args.bestelling.adres))
            {
                _rapport.Add(args.bestelling.adres, new List<Bestelling>());
            }
            
            _rapport[args.bestelling.adres].Add(args.bestelling);

        }
        public void Rapport()
        {
            foreach (KeyValuePair<string , List<Bestelling>> item in _rapport)
            {
                Console.WriteLine(item.Key);
                foreach (Bestelling bestelling in item.Value)
                {
                    Console.WriteLine($"{bestelling.aantal} {bestelling.type}");
                }
            }
        }

    }
}
