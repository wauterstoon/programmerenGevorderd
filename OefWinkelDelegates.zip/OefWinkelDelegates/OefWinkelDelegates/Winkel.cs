﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OefWinkelDelegates
{
    class Winkel
    {

        public void VerkoopProduct(Bestelling b)
        {

            Console.WriteLine("---------");
            Console.WriteLine("Sales - Rapport");
            Console.WriteLine($"{b.adres}");
            Console.WriteLine($"{b.type},{b.aantal}");
            OnWinkelVerkooop(b);
            
        }
        public event EventHandler<WinkelEventArgs> WinkelVerkoop;
        protected virtual void OnWinkelVerkooop(Bestelling b)
        {
            WinkelVerkoop?.Invoke(this, new WinkelEventArgs { bestelling = b });
         
        }

    }
}
