﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OefWinkelDelegates
{
   public class StockBeheeerEventArgs
    {
        public List<int> Aanvullen { get; set; }
    }
}
