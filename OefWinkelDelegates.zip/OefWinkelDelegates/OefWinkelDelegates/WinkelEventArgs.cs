﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OefWinkelDelegates
{
    public class WinkelEventArgs
    {
        public Bestelling bestelling { get; set; }
    }
}
