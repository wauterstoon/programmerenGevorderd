﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OefWinkelDelegates
{
   public class StockBeheer
    {
        private List<int> _stock = new List<int> { 100, 100, 100, 100 };
        private int MinimumAantal = 50;
        private int MaximumAantal = 100;
        public List<int> LageStock = new List<int>() { 0, 0, 0, 0 };


        public void OnWinkelVerkoop(object obj, WinkelEventArgs args)
        {
            //bepaal index producttype, pas stock aan
            int stockIndex = 1;
            switch (args.bestelling.type.ToString())
            {
                case "Trippel": stockIndex = 0; break;
                case "Dubbel": stockIndex = 1; break;
                case "Kriek": stockIndex = 2; break;
                case "Pils": stockIndex = 3; break;
            }
            _stock[stockIndex] -= args.bestelling.aantal;

            //nieuwe aantal instock indien nodig bij bestellen
            if (_stock[stockIndex] < MinimumAantal)
            {
                LageStock = new List<int>() { 0, 0, 0, 0 };
                for (int i = 0; i < _stock.Count; i++)
                {
                    //aantallen te bestellen
                    if (_stock[i] < MaximumAantal)
                    {
                        LageStock[i] = 100 - _stock[i];
                        
                        _stock[i] = 100;
                        Console.WriteLine($"voorraadbestelling\n  {LageStock}\n  {_stock}");
                    }
                }
                //stuur aan te vullen aantallen naar groothandelaar
                OnStockaanvulling(LageStock);
            }
        }

       
        public event EventHandler<StockBeheeerEventArgs> StockAanvulling;

        protected virtual void OnStockaanvulling(List<int> A)
        {
            StockAanvulling?.Invoke(this, new StockBeheeerEventArgs { Aanvullen = A });
        }

     
        public void ShowStock()
        {
            Console.WriteLine(
                $"------------\n[stock:Trippel, {_stock[0]}]\n[stock:Dubbel,  {_stock[1]}]\n[stock:Kriek,  {_stock[2]}]\n[stock:Pils,    {_stock[3]}]\n------------");
        }

    }
}
