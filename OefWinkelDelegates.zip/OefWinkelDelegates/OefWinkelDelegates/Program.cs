﻿using System;

namespace OefWinkelDelegates
{
    class Program
    {
        static void Main()
        {


            Winkel w = new Winkel(); 
            Sales s = new Sales(); 
            w.WinkelVerkoop += s.OnWinkelVerkoop;
            StockBeheer sb = new StockBeheer(); 
            w.WinkelVerkoop += sb.OnWinkelVerkoop;
            Groothandelaar gh = new Groothandelaar();
            sb.StockAanvulling += gh.OnStockAanvulling;

            Bestelling b1 = new Bestelling { aantal = 4, adres = "cafe1", prijs = 1 * 1.5, type = ProductType.Kriek };
            Bestelling b2 = new Bestelling { aantal = 1, adres = "cafe2", prijs = 5 * 2, type = ProductType.Tripel };
            Bestelling b3 = new Bestelling { aantal = 2, adres = "cafe3", prijs = 76 * 1.5, type = ProductType.Pils };
            Bestelling b4 = new Bestelling { aantal = 3, adres = "cafe4", prijs = 1 * 1.5, type = ProductType.Dubbel };
            Bestelling b5 = new Bestelling { aantal = 5, adres = "cafe5", prijs = 1 * 1.5, type = ProductType.Tripel };
            Bestelling bb1 = new Bestelling { aantal = 50, adres = "cafe1", prijs = 1 * 1.5, type = ProductType.Kriek };
            Bestelling bb2 = new Bestelling { aantal = 30, adres = "cafe2", prijs = 1 * 1.5, type = ProductType.Kriek };
            Bestelling bb3 = new Bestelling { aantal = 60, adres = "cafe3", prijs = 1 * 1.5, type = ProductType.Pils };
            Bestelling bb4 = new Bestelling { aantal = 70, adres = "cafe4", prijs = 1 * 1.5, type = ProductType.Dubbel };

            w.VerkoopProduct(b1);
            w.VerkoopProduct(b2);
            w.VerkoopProduct(b3);
            w.VerkoopProduct(b4);
            w.VerkoopProduct(b5);
            w.VerkoopProduct(bb1);
            w.VerkoopProduct(bb2);
            w.VerkoopProduct(bb3);
            w.VerkoopProduct(bb4);
            sb.ShowStock();

            s.Rapport();
            gh.AlleAanvullingen();
            gh.LaatsteAanvulling();
        }
    }
}
